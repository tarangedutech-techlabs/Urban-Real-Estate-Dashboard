// Monthly Sales
new Chart(document.getElementById("salesChart"), {
  type: "bar",
  data: {
    labels: ["Jan","Feb","Mar","Apr","May","Jun"],
    datasets: [{
      label: "Units Sold",
      data: [45, 60, 52, 75, 68, 90],
      backgroundColor: "#4f46e5"
    }]
  }
});

// Revenue Trend
new Chart(document.getElementById("revenueChart"), {
  type: "line",
  data: {
    labels: ["Jan","Feb","Mar","Apr","May","Jun"],
    datasets: [{
      label: "Revenue (₹ Cr)",
      data: [2.1,2.4,2.8,3.0,3.2,3.6],
      borderColor: "#16a34a",
      fill: false,
      tension: 0.4
    }]
  }
});

// Property Type Sales
new Chart(document.getElementById("propertyChart"), {
  type: "doughnut",
  data: {
    labels: ["1 BHK","2 BHK","Plots","Commercial"],
    datasets: [{
      data: [320,450,210,180],
      backgroundColor: ["#3b82f6","#6366f1","#f59e0b","#ef4444"]
    }]
  }
});
